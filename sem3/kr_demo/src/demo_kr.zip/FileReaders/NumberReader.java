package FileReaders;

import Container.Container;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class NumberReader {
    public static void readNumbersFromFile(File file, Container<Double> numbers) throws FileNotFoundException {
        Scanner scanner = new Scanner(file);
        while (scanner.hasNext()) {
            Double num = Double.parseDouble(scanner.next());
            numbers.add(num);
        }
    }
}
