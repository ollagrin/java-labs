package Container;

import Exceptions.EmptyException;

import java.util.ArrayList;
import java.util.Collections;

public class Container<T extends Comparable<T>> extends ArrayList<T>{
    public T max() throws EmptyException {
        return Collections.max(this);
    }

    public T min() throws EmptyException{
        return Collections.min(this);
    }
}
