package ProgrammingTest;

import Container.*;
import Exceptions.EmptyException;
import FileReaders.*;

import java.io.File;
import java.io.FileNotFoundException;

public class Main {
    public static void main(String[] args) {
        Container<Double> numbers = new Container<Double>();
        File fileWithNumbers = new File
                ("C:\\Users\\olgag\\OneDrive\\Рабочий стол\\учеба\\2 курс\\прога\\KR_DEMO\\src\\numbers.txt");
        try {
            NumberReader.readNumbersFromFile(fileWithNumbers, numbers);
            System.out.println(numbers.max());
            System.out.println(numbers.min());
        } catch (FileNotFoundException | EmptyException e) {
            e.printStackTrace();
        }

        Container<Student> students = new Container<Student>();
        File fileWithStudents = new File
                ("C:\\Users\\olgag\\OneDrive\\Рабочий стол\\учеба\\2 курс\\прога\\KR_DEMO\\src\\students.txt");
        try{
            StudentsReader.readStudentsFromFile(fileWithStudents, students);
            System.out.println(students.max());
            System.out.println(students.min());
        } catch (FileNotFoundException | EmptyException e) {
            e.printStackTrace();
        }
    }
}
